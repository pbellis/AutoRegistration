#ifndef PREDICTION_H
#define PREDICTION_H

#include "alignmentpredictionlib_global.h"

// TODO
// IMPLEMENT FUNCTION THAT TIES EVERYTHING TOGETHER!

#endif // PREDICTION_H
